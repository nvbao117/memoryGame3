package game;

import java.util.HashMap;
import java.util.Map;
import javax.swing.ImageIcon;

public class Images {
    private class Item {
        Integer intCod;
        String strNomeRecurso;
        Item(Integer intCod, String strNomeRecurso) {
            this.intCod = intCod;
            this.strNomeRecurso = strNomeRecurso;
        }
    }

    private final Map<Integer, Item> mapa;
    
    public Images() {
        mapa = new HashMap<>();
        preenche();
    }

    public String getResourceName(Integer intCod) {
        return mapa.get(intCod).strNomeRecurso;
    }

    public ImageIcon IconFactory(Integer intCod) {
        if(!mapa.containsKey(intCod)) {
            System.out.println("IconFactory problem");
            return null;
        }
        return new ImageIcon(
                getClass()
                        .getClassLoader()
                        .getResource(getResourceName(intCod)));
    }

    private void preenche() {
        Item item;
        int i = -1;

        item = new Item(i++, "images/ic_help_outline_black_18dp.png");
        mapa.put(item.intCod, item);
                	
        // discovered image
        item = new Item(i++, "images/ic_done_black_18dp.png");
        mapa.put(item.intCod, item);
        
     
        item = new Item(i++, "images/bee.png");
        mapa.put(item.intCod, item);
        item = new Item(i++, "images/cat.png");
        mapa.put(item.intCod, item);
        item = new Item(i++, "images/chicken.png");
        mapa.put(item.intCod, item);
        item = new Item(i++, "images/cow.png");
        mapa.put(item.intCod, item);
        item = new Item(i++, "images/dino.png");
        mapa.put(item.intCod, item);
        item = new Item(i++, "images/dog.png");
        mapa.put(item.intCod, item);
        item = new Item(i++, "images/duck.png");
        mapa.put(item.intCod, item);
        item = new Item(i++, "images/fish.png");
        mapa.put(item.intCod, item);
        item = new Item(i++, "images/fox.png");
        mapa.put(item.intCod, item);
        item = new Item(i++, "images/frog.png");
        mapa.put(item.intCod, item);
        item = new Item(i++, "images/hamster.png");
        mapa.put(item.intCod, item);
        item = new Item(i++, "images/penguin.png");
        mapa.put(item.intCod, item);
        item = new Item(i++, "images/pig.png");
        mapa.put(item.intCod, item);
        item = new Item(i++, "images/rabbit.png");
        mapa.put(item.intCod, item);
    }
}
